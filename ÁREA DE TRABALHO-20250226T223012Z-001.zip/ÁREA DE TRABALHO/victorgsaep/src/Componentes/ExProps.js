function ExProps({noMe, idAde, HabilIdade}) { //function nome_arquivo
    return (
        <div>
            <p>Nome: {noMe}</p>
            <p>Idade: {idAde}, anos.</p> 
            <p>Habilidade: {HabilIdade}</p>
        </div>
    )
}

export default ExProps; //export default nome_arquivo