function Componente() { //function nome_arquivo
    return ( //Deve ter uma único tag, ou seja tudo dentro de uma "div", ou usar "<></>" para encher de "divs".
        // "React fragments" = "<> </>"
        <>
            <br/>
            <p>Testando Componente</p>
            <p>E não é só uma linha!!!</p>
            <br/>
        </>
        //Componentes dentro de componentes.
    )
}

export default Componente // export default nome_arquivo
                          // Mesmo nome do arquivo 

// Criar um "componente" é como criar um "tag".