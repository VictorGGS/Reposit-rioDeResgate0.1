import { useState } from "react";

function Formulario() {

    const[usuArio, setUsuario] = useState()
        // "noMe" é a variável, "setNome" permite usar a variável.
    const[seNha, setSenha] = useState()
        // "seNha" é a variável, "setSenha" permite usar a variável.
    const[cPf, setCPF] = useState()
    const[genEro, setGenero] = useState()
    const[orIen, setOrientacao] = useState()

    function Logar(seim) { //Não pode ter load. Para evitar, coloque alguma variável. 
                           //Ex.: "seim ou evento".
        seim.preventDefault() //"preventeDefault" Previne o "DEFAULT" = Padrão.
        setUsuario(usuArio)
        setSenha(seNha)
        setCPF(cPf)
        setGenero(genEro)
        setOrientacao(orIen)
        alert(usuArio + " está Logado")
    }

    function Deslogar(seim /*Desde que sejam funções diferente os nomes podem ser os mesmos*/) {
        seim.preventDefault()
        setUsuario('')
    }

    return ( // Não tem "</input>", input não tem fechamento.
        <>
            <form onSubmit={Logar} className="meuForm"> 
                <label htmlFor="">Usuário: </label>
                <input type="text" name="usuario" id="usuario" onChange={(seim) => setUsuario(seim.target.value)}/>
                                                                <br/><br/>
                <label htmlFor="">Senha: </label>
                <input type="password" name="senha" id="senha" onChange={(seim) => setSenha(seim.target.value)}/> 
                                                                <br/><br/> 
                <label htmlFor="">CPF: </label>
                <input type="text" name="cpf" id="cpf" onChange={(seim) => setGenero(seim.target.value)}/>
                                                                <br/><br/> 
                <label htmlFor="">Genêro: </label> <br/>
                <input type="radio" name="genero" id="genero" onChange={(seim) => setGenero(seim.target.value)}/>
                <label htmlFor="">Masculino</label> <br/>
                <input type="radio" name="genero" id="genero" onChange={(seim) => setGenero(seim.target.value)}/>
                <label htmlFor="">Feminino</label> <br/>
                                                                <br/>
                <label htmlFor="">Orientação Sexual: </label> <br/>
                <input type="radio" name="sexo" id="sexo" onChange={(seim) => setOrientacao(seim.target.value)}/>
                <label htmlFor="">Hétero</label> <br/>
                <input type="radio" name="sexo" id="sexo" onChange={(seim) => setOrientacao(seim.target.value)}/>
                <label htmlFor="">Homossexaul</label> <br/>
                <input type="radio" name="sexo" id="sexo" onChange={(seim) => setOrientacao(seim.target.value)}/>
                <label htmlFor="">Bruno</label> <br/>
                <input type="radio" name="sexo" id="sexo" onChange={(seim) => setOrientacao(seim.target.value)}/>
                <label htmlFor="">Transexual</label> <br/>
                <input type="radio" name="sexo" id="sexo" onChange={(seim) => setOrientacao(seim.target.value)}/>
                <label htmlFor="">Hermafrodita (Weslly)</label> <br/>
                <input type="radio" name="sexo" id="sexo" onChange={(seim) => setOrientacao(seim.target.value)}/>
                <label htmlFor="">Nada à Declarar</label> <br/>
                                                                <br/>
                <input type="submit"/>
            </form>
                                                                <br/>
            {usuArio &&(//Rederização Condicional: Quando esse campo for preenchido, este conteúdo aparecerá.   
                <div>
                    <h1>Wow Yeah!</h1>
                                        <br/>
                    <button onClick={Deslogar}>Tamo Junto {usuArio}</button>
                </div>
            )}

        </>
    )
}

export default Formulario;