function AlgumComponente() { // "{}" = JavaScript
    return ( // "()" = HTML
        <>
            <h1 className="algumComponente">
                ALGUM COMPONENTE
            </h1>
        </>
    )
}

export default AlgumComponente;