import logo from './logo.svg';
import './App.css';
import Linkin_Park from './Linkin_Park.jpg';
import Componente from './Componentes/Componente';
import ExProps from './Componentes/ExProps';
import AlgumComponente from './Componentes/AlgumComponente';
import Formulario from './Componentes/Formulario';

function App() {
  
  const rOck = 'Long Live Rock and Roll' //Dá para criar vaiáveis.

  function aleatoria(n1, n2) {
    return (n1+n2);
  }

  return (
    <div className="App">
                                                  <br/><br/>
      <h1>{rOck}</h1>
      <h2>{aleatoria(1280, 640)}</h2>
                                                  <br/><br/>
      <p>I've become so numb</p>
                                                  <br/>
      <img src={Linkin_Park} alt='O Novo Linkin Park' width={900}/>
                                                  <br/><br/>
      <Formulario/>
                                                  <br/><br/>
      <AlgumComponente/>
      <AlgumComponente/>
      <AlgumComponente/>
                                                  <br/>
      <Componente/>
      <ExProps noMe='Qin Shihuang' idAde='2283' HabilIdade='Sentir a Dor do Oponente.'/>
                                                  <br/>
                                                  <br/>
    </div>
  );
}

export default App;